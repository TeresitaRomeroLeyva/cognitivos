<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <!-- title -->
        <title>Builder - Multipurpose Marketing Landing Page Pack with Page Builder</title>
        <meta name="description" content="lgdescription" />
        <meta name="keywords" content="lgkeywords" />
        <meta name="author" content="lgauthor">
        <!-- favicon -->
        <link rel="shortcut icon" href="images/icon/favicon.png">
        <!-- animation -->
        <link rel="stylesheet" href="css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <!-- themify-icons -->
        <link rel="stylesheet" href="css/themify-icons.css" />
        <!-- owl carousel -->
        <link rel="stylesheet" href="css/owl.transitions.css" />
        <link rel="stylesheet" href="css/owl.carousel.css" /> 
        <!-- magnific popup -->
        <link rel="stylesheet" href="css/magnific-popup.css" /> 
        <!-- base -->
        <link rel="stylesheet" href="css/base.css" /> 
        <!-- elements -->
        <link rel="stylesheet" href="css/elements.css" />
        <!-- responsive -->
        <link rel="stylesheet" href="css/responsive.css" />
        <!--[if IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
        <![endif]-->
        <!--[if IE]>
            <script src="js/html5shiv.min.js"></script>
        <![endif]-->
    </head>
    <body>
        

        <div id="page" class="page">

            <?php include('header2.php'); ?>

  <section id="pricing-table6" class="padding-110px-tb position-relative cover-background tz-builder-bg-image border-none xs-padding-60px-tb" data-img-size="(W)1920px X (H)900px" style="background:linear-gradient(rgba(0,0,0,0.01), rgba(0,0,0,0.01)), url('images/bg-image/hero-bg27.jpg')">
                <div class="container position-relative">
                    <div class="row">
                        <div class="pricing-box-style6 display-inline-block width-100">
                            <!-- pricing item -->
                            <div class="col-md-4 col-sm-4 col-xs-12 text-center xs-margin-fifteen-bottom">
                                <div class="pricing-box border-radius-8 tz-background-color">
                                    <!-- pricing title -->
                                    <div class="pricing-title border-radius-6 bg-white text-center tz-background-color margin-fifteen-bottom">
                                        <div class="margin-eight-bottom"><i class="fa ti-user title-extra-large-2 text-light-gray margin-five-bottom tz-icon-color"></i></div>
                                        <h3 class="alt-font text-large text-dark-gray tz-text">PERSONAL</h3>
                                        <h4 class="title-extra-large-2 sm-title-extra-large-2 alt-font font-weight-400 text-pink tz-text">$250</h4>
                                        <div class="text-small2 alt-font no-margin-bottom tz-text"> <p class="no-margin-bottom"> PER EVERY YEAR</p> </div>
                                    </div>
                                    <!-- end pricing title -->
                                    <!-- pricing features -->
                                    <div class="pricing-features">
                                        <ul class="margin-twenty-three-bottom xs-margin-fifteen-bottom alt-font text-middle-gray list-style-none">
                                            <li><span class="tz-text">1 GB Photos</span></li>
                                            <li><span class="tz-text">Secure Online Transfer</span></li>
                                            <li><span class="tz-text">Unlimited Styles</span></li>
                                            <li><span class="tz-text">Customer Service</span></li>
                                            <li><span class="tz-text">Manual Backup</span></li>
                                        </ul>
                                        <!-- pricing action -->
                                        <div class="pricing-action">
                                            <a class="btn-medium btn btn-circle bg-pink text-white no-letter-spacing" href="#"><span class="tz-text">CHOOSE PLAN</span></a>
                                        </div>
                                        <!-- end pricing action -->
                                    </div>
                                    <!-- end pricing features -->
                                </div>
                            </div>
                            <!-- end pricing item -->
                            <!-- pricing item -->
                            <div class="col-md-4 col-sm-4 col-xs-12 text-center xs-margin-fifteen-bottom">
                                <div class="pricing-box border-radius-8 tz-background-color">
                                    <!-- pricing title -->
                                    <div class="pricing-title border-radius-6 bg-white text-center tz-background-color margin-fifteen-bottom">
                                        <div class="margin-eight-bottom"><i class="fa ti-briefcase title-extra-large-2 text-light-gray margin-five-bottom tz-icon-color"></i></div>
                                        <h3 class="alt-font text-large text-dark-gray tz-text">BUSINESS</h3>
                                        <h4 class="title-extra-large-2 sm-title-extra-large-2 alt-font font-weight-400 text-pink tz-text">$350</h4>
                                        <div class="text-small2 alt-font no-margin-bottom tz-text"> <p class="no-margin-bottom"> PER EVERY YEAR</p> </div>
                                    </div>
                                    <!-- end pricing title -->
                                    <!-- pricing features -->
                                    <div class="pricing-features">
                                        <ul class="margin-twenty-three-bottom xs-margin-fifteen-bottom alt-font text-middle-gray list-style-none">
                                            <li><span class="tz-text">1 GB Photos</span></li>
                                            <li><span class="tz-text">Secure Online Transfer</span></li>
                                            <li><span class="tz-text">Unlimited Styles</span></li>
                                            <li><span class="tz-text">Customer Service</span></li>
                                            <li><span class="tz-text">Manual Backup</span></li>
                                        </ul>
                                        <!-- pricing action -->
                                        <div class="pricing-action">
                                            <a class="btn-medium btn btn-circle bg-pink text-white no-letter-spacing" href="#"><span class="tz-text">CHOOSE PLAN</span></a>
                                        </div>
                                        <!-- end pricing action -->
                                    </div>
                                    <!-- end pricing features -->
                                </div>
                            </div>
                            <!-- end pricing item -->
                            <!-- pricing item -->
                            <div class="col-md-4 col-sm-4 col-xs-12 text-center">
                                <div class="pricing-box border-radius-8 tz-background-color">
                                    <!-- pricing title -->
                                    <div class="pricing-title border-radius-6 bg-white text-center tz-background-color margin-fifteen-bottom">
                                        <div class="margin-eight-bottom"><i class="fa ti-world title-extra-large-2 text-light-gray margin-five-bottom tz-icon-color"></i></div>
                                        <h3 class="alt-font text-large text-dark-gray tz-text">ULTIMATE</h3>
                                        <h4 class="title-extra-large-2 sm-title-extra-large-2 alt-font font-weight-400 text-pink tz-text">$450</h4>
                                        <div class="text-small2 alt-font no-margin-bottom tz-text"> <p class="no-margin-bottom"> PER EVERY YEAR</p> </div>
                                    </div>
                                    <!-- end pricing title -->
                                    <!-- pricing features -->
                                    <div class="pricing-features">
                                        <ul class="margin-twenty-three-bottom xs-margin-fifteen-bottom alt-font text-middle-gray list-style-none">
                                            <li><span class="tz-text">1 GB Photos</span></li>
                                            <li><span class="tz-text">Secure Online Transfer</span></li>
                                            <li><span class="tz-text">Unlimited Styles</span></li>
                                            <li><span class="tz-text">Customer Service</span></li>
                                            <li><span class="tz-text">Manual Backup</span></li>
                                        </ul>
                                        <!-- pricing action -->
                                        <div class="pricing-action">
                                            <a class="btn-medium btn btn-circle bg-pink text-white no-letter-spacing" href="#"><span class="tz-text">CHOOSE PLAN</span></a>
                                        </div>
                                        <!-- end pricing action -->
                                    </div>
                                    <!-- end pricing features -->
                                </div>
                            </div>
                            <!-- end pricing item -->
                        </div>
                    </div>
                </div>
            </section> <?php include('footer.php'); ?></div><!-- /#page -->


        <!-- javascript libraries -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery.appear.js"></script>
        <script type="text/javascript" src="js/smooth-scroll.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <!-- wow animation -->
        <script type="text/javascript" src="js/wow.min.js"></script>
        <!-- owl carousel -->
        <script type="text/javascript" src="js/owl.carousel.min.js"></script>        
        <!-- images loaded -->
        <script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
        <!-- isotope -->
        <script type="text/javascript" src="js/jquery.isotope.min.js"></script> 
        <!-- magnific popup -->
        <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
        <!-- navigation -->
        <script type="text/javascript" src="js/jquery.nav.js"></script>
        <!-- equalize -->
        <script type="text/javascript" src="js/equalize.min.js"></script>
        <!-- fit videos -->
        <script type="text/javascript" src="js/jquery.fitvids.js"></script>
        <!-- number counter -->
        <script type="text/javascript" src="js/jquery.countTo.js"></script>
        <!-- time counter  -->
        <script type="text/javascript" src="js/counter.js"></script>
        <!-- twitter Fetcher  -->
        <script type="text/javascript" src="js/twitterFetcher_min.js"></script>
        <!-- main -->
        <script type="text/javascript" src="js/main.js"></script>
    

    </body>
</html>
        