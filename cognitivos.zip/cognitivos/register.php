<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <!-- title -->
        <title>Builder - Multipurpose Marketing Landing Page Pack with Page Builder</title>
        <meta name="description" content="lgdescription" />
        <meta name="keywords" content="lgkeywords" />
        <meta name="author" content="lgauthor">
        <!-- favicon -->
        <link rel="shortcut icon" href="images/icon/favicon.png">
        <!-- animation -->
        <link rel="stylesheet" href="css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <!-- themify-icons -->
        <link rel="stylesheet" href="css/themify-icons.css" />
        <!-- owl carousel -->
        <link rel="stylesheet" href="css/owl.transitions.css" />
        <link rel="stylesheet" href="css/owl.carousel.css" /> 
        <!-- magnific popup -->
        <link rel="stylesheet" href="css/magnific-popup.css" /> 
        <!-- base -->
        <link rel="stylesheet" href="css/base.css" /> 
        <!-- elements -->
        <link rel="stylesheet" href="css/elements.css" />
        <!-- responsive -->
        <link rel="stylesheet" href="css/responsive.css" />
        <!--[if IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
        <![endif]-->
        <!--[if IE]>
            <script src="js/html5shiv.min.js"></script>
        <![endif]-->
    </head>
    <body>
        

        <div id="page" class="page">
        <?php include('header2.php'); ?>
        <section class="padding-110px-tb bg-dark-blue builder-bg contact-form-style1 xs-padding-60px-tb border-none" id="contact-section20">

                <div class="container">
                    <div class="row">
                        <!-- contact form -->
                        <div class="col-md-offset-3 col-sm-offset-3 col-md-6 col-sm-6 col-xs-12" style="text-align: center;">
                            <div class="padding-eighteen bg-black-light-rgba tz-background-color xs-padding-eleven border-radius-8 col-lg-12">
                                <h5 class="alt-font font-weight-100 text-white display-block tz-text margin-fifteen-bottom" style="font-size: 2.2em;">Registro</h5>
                                <form action="javascript:void(0)" method="post">
                                    <input class=" col-md-offset-1 col-lg-5 col-md-5 " type="text" name="name" data-email="required" id="name" placeholder="* Nombre(s)" class="medium-input" style="margin-right: 5px;">   

                                    <input class=" col-lg-5 col-md-5 " type="text" name="last_name" data-email="required" id="password" placeholder="* Apellidos" class="medium-input" style="margin-right: 5px;">

                                    <input class="col-md-offset-1 col-lg-5 col-md-5 " type="text" name="address" data-email="required" id="password" placeholder="* Dirección" class="medium-input" style="margin-right: 5px;">

                                    <input class="col-lg-5 col-md-5 " type="text" name="city" data-email="required" id="password" placeholder="* País" class="medium-input" style="margin-right: 5px;">

                                    <input class="col-md-offset-1 col-lg-5 col-md-5 " type="select" name="country" data-email="required" id="password" placeholder="* Ciudad" class="medium-input" style="margin-right: 5px;">

                                    <input class="col-lg-5 col-md-5 " type="select" name="state" data-email="required" id="password" placeholder="* Estado" class="medium-input" style="margin-right: 5px;">

                                    <input class="col-md-offset-1 col-lg-5 col-md-5 " type="text" name="phone" data-email="required" id="password" placeholder="* Télefono" class="medium-input" style="margin-right: 5px;">

                                    <input class="col-lg-5 col-md-5 " type="text" name="email" data-email="required" id="password" placeholder="* Correo Electronico" class="medium-input" style="margin-right: 5px;">

                                    <input class="col-md-offset-1 col-lg-5 col-md-5 " type="password" name="password" data-email="required" id="password" placeholder="* Contraseña" class="medium-input" style="margin-right: 5px;">

                                    <input class=" col-lg-5 col-md-5 " type="password" name="confirm_password" data-email="required" id="password" placeholder="*Confirmar Contraseña" class="medium-input" style="margin-right: 5px;">
                                    <br>


                                                      
                                  <button style="background-color: rgb(7, 143, 180) !important;" class=" col-lg-offset-4 col-md-offset-0 col-xs-offset-4 col-lg-12 tz_submit btn-large  font-weight-300 btn bg-sky-blue text-white tz-text" type="submit">Registrar</button>                                  
                                </form>
                            </div>
                            
                            
                        </div>
                        <!-- end contact form -->
                    </div>
                </div>
            </section> <?php include('footer.php'); ?></div><!-- /#page -->


        <!-- javascript libraries -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery.appear.js"></script>
        <script type="text/javascript" src="js/smooth-scroll.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <!-- wow animation -->
        <script type="text/javascript" src="js/wow.min.js"></script>
        <!-- owl carousel -->
        <script type="text/javascript" src="js/owl.carousel.min.js"></script>        
        <!-- images loaded -->
        <script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
        <!-- isotope -->
        <script type="text/javascript" src="js/jquery.isotope.min.js"></script> 
        <!-- magnific popup -->
        <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
        <!-- navigation -->
        <script type="text/javascript" src="js/jquery.nav.js"></script>
        <!-- equalize -->
        <script type="text/javascript" src="js/equalize.min.js"></script>
        <!-- fit videos -->
        <script type="text/javascript" src="js/jquery.fitvids.js"></script>
        <!-- number counter -->
        <script type="text/javascript" src="js/jquery.countTo.js"></script>
        <!-- time counter  -->
        <script type="text/javascript" src="js/counter.js"></script>
        <!-- twitter Fetcher  -->
        <script type="text/javascript" src="js/twitterFetcher_min.js"></script>
        <!-- main -->
        <script type="text/javascript" src="js/main.js"></script>
    

    </body>
</html>
        