      <header class="header-style1" id="header-section4">
                <!-- nav -->
                <nav class="navbar bg-black tz-header-bg black-header no-margin alt-font shrink-header dark-header">
                    <div class="container navigation-menu">
                        <div class="row">
                            <!-- logo -->
                            <div class="col-md-3 col-sm-4 col-xs-9">
                                <a href="#home" class="inner-link"><img alt="" src="images/logo-white.png" data-img-size="(W)163px X (H)40px"></a>
                            </div>
                            <!-- end logo -->
                            <div class="col-md-9 col-sm-8 col-xs-3 position-inherit">
                                <button data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse pull-right">
                                    <ul class="nav navbar-nav">
                                        <li class="propClone"><a class="inner-link" href="#">SECTION 1</a></li>
                                        <li class="propClone"><a class="inner-link" href="#">SECTION 2</a></li>
                                        <li class="propClone"><a class="inner-link" href="#">SECTION 3</a></li>
                                        <li class="propClone sm-no-border"><a class="inner-link" href="#">SECTION 4</a></li>                                    
                                        <li class="nav-button propClone float-left btn-medium sm-no-margin-tb sm-no-border"><a href="#" class="inner-link btn btn-small propClone bg-light-green text-black border-radius-0 font-weight-300 sm-padding-nav-btn sm-display-inline-block">JOIN US</a> </li>
                                        <li class="nav-button propClone float-left btn-medium sm-no-margin-tb sm-no-margin-left"><a href="#" class="inner-link btn btn-small propClone bg-light-green text-black border-radius-0 font-weight-300 sm-padding-nav-btn sm-display-inline-block">DOWNLOAD</a> </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav> 
                <!-- end nav -->
            </header>