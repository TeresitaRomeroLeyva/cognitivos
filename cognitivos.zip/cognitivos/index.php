<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <!-- title -->
        <title>Builder - Multipurpose Marketing Landing Page Pack with Page Builder</title>
        <meta name="description" content="lgdescription" />
        <meta name="keywords" content="lgkeywords" />
        <meta name="author" content="lgauthor">
        <!-- favicon -->
        <link rel="shortcut icon" href="images/icon/favicon.png">
        <!-- animation -->
        <link rel="stylesheet" href="css/animate.css" />
        <!-- bootstrap -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="css/font-awesome.min.css" />
        <!-- themify-icons -->
        <link rel="stylesheet" href="css/themify-icons.css" />
        <!-- owl carousel -->
        <link rel="stylesheet" href="css/owl.transitions.css" />
        <link rel="stylesheet" href="css/owl.carousel.css" /> 
        <!-- magnific popup -->
        <link rel="stylesheet" href="css/magnific-popup.css" /> 
        <!-- base -->
        <link rel="stylesheet" href="css/base.css" /> 
        <!-- elements -->
        <link rel="stylesheet" href="css/elements.css" />
        <!-- responsive -->
        <link rel="stylesheet" href="css/responsive.css" />
        <!--[if IE 9]>
        <link rel="stylesheet" type="text/css" href="css/ie.css" />
        <![endif]-->
        <!--[if IE]>
            <script src="js/html5shiv.min.js"></script>
        <![endif]-->
    </head>
    <body>
        

        <div id="page" class="page">

        <div class="header-style8">                
                <header class="header-style8" id="header-section16">
                    <!-- nav -->
                    <nav class="navbar tz-header-bg no-margin alt-font navigation-menu dark-header">
                        <!-- logo -->
                        <div class="pull-left">
                            <a href="#home" class="inner-link"><img alt="" src="images/logo-white.png" data-img-size="(W)163px X (H)40px"></a>
                        </div>
                        <!-- end logo -->
                        <div class="pull-right">
                            <button data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse pull-right">
                                <ul class="nav navbar-nav">
                                    <li class="propClone"><a class="inner-link" href="#">SECTION 1</a></li>
                                    <li class="propClone"><a class="inner-link" href="#">SECTION 2</a></li>
                                    <li class="propClone"><a class="inner-link" href="#">SECTION 3</a></li>
                                    <li class="propClone"><a class="inner-link" href="#">SECTION 4</a></li>
                                    <li class="propClone"><a class="inner-link" href="#">SECTION 5</a></li>
                                    <li class="propClone sm-no-border"><a class="inner-link" href="#">SECTION 6</a></li>
                                    <li class="nav-button propClone float-left btn-medium sm-no-margin-tb"><a href="#" class="sm-text-medium display-block sm-bg-white text-black sm-padding-nav-btn width-100 sm-display-inline-block sm-width-auto"><i class="fa fa-user tz-icon-color" aria-hidden="true"></i> REGISTER</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav> 
                    <!-- end nav -->
                </header>
                <section class="no-padding cover-background tz-builder-bg-image" data-img-size="(W)1920px X (H)750px" style="background:linear-gradient(rgba(0,0,0,0.01), rgba(0,0,0,0.01)), url('images/bg-image/corporate-bg.jpg');">
                    <div class="container one-fourth-screen position-relative">
                        <div class="slider-typography text-center">
                            <div class="slider-text-middle-main">
                                <div class="slider-text-middle">
                                    <!-- slider text -->
                                    <div class="col-md-12 header-banner">
                                        <a href="https://www.youtube.com/watch?v=_xG68lkrMDU" class="tz-edit title-extra-large-6 text-white margin-five-bottom display-inline-block banner-icon popup-youtube">
                                            <i class="fa fa-play-circle tz-icon-color"></i>
                                        </a>
                                        <div class="text-white font-weight-700 title-extra-large-3 alt-font margin-two-bottom banner-title xs-margin-seven-bottom">
                                            <span class="tz-text">WE ARE READY TO HELP YOU</span>
                                        </div>
                                        <div class="text-white title-medium sm-title-medium margin-six-bottom banner-text width-60 md-width-90 center-col">
                                            <span class="tz-text">Present your app in beautiful way with leadgen builder. Get the Best Solution for Your Business.</span>
                                        </div>
                                        <div class="display-inline-block margin-one">
                                            <a class="font-weight-700 btn-large btn line-height-20 bg-white text-black no-letter-spacing" href="#"><span class="tz-text">GET STARTED</span><i class="fa fa-caret-right tz-icon-color"></i></a>
                                        </div>
                                        <div class="display-inline-block margin-one">
                                            <a class="font-weight-700 btn-large btn line-height-20 bg-white text-black no-letter-spacing" href="#"><span class="tz-text">LEARN MORE</span><i class="fa fa-caret-right tz-icon-color"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <!-- end slider text -->
                                </div>
                            </div>
                        </div>
                    </div>
                </section>                
            </div><section class="padding-110px-tb xs-padding-60px-tb bg-white builder-bg" id="content-section3">
                <div class="container">                    
                    <div class="row">
                        <!-- section title -->
                        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                            <h2 class="section-title-large sm-section-title-medium xs-section-title-large text-dark-gray font-weight-600 alt-font margin-three-bottom xs-margin-fifteen-bottom tz-text">Get The Most Amazing Builder!</h2>
                            <div class="text-medium sm-text-medium width-60 margin-lr-auto md-width-70 sm-width-100 tz-text margin-thirteen-bottom xs-margin-nineteen-bottom">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</div>
                        </div>
                        <!-- end section title -->
                        <!-- image -->
                        <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                            <img class="margin-thirteen-bottom xs-margin-twenty-seven-bottom" src="images/application-about-mobile.png" data-img-size="(W)958px X (H)115px" alt="">
                        </div>
                        <!-- end image -->
                    </div>                    
                    <div class="row four-column">
                        <!-- feature box -->
                        <div class="col-md-3 col-sm-6 col-xs-12 text-center sm-margin-nine-bottom xs-margin-seventeen-bottom">
                            <i class="fa ti-world tz-icon-color icon-extra-large text-sky-blue margin-twenty-bottom xs-margin-nine-bottom" aria-hidden="true"></i>
                            <h3 class="text-medium sm-text-medium alt-font display-block margin-three-bottom xs-margin-five-bottom tz-text">SOCIAL CONNECT</h3>
                            <div class="text-medium center-col xs-width-100 tz-text"><p class="no-margin-bottom">Lorem Ipsum is simply dummy of the printing and typesetting and industry. Lorem Ipsum been.</p></div>
                        </div>    
                        <!-- end feature box -->
                        <!-- feature box -->
                        <div class="col-md-3 col-sm-6 col-xs-12 text-center sm-margin-nine-bottom xs-margin-seventeen-bottom">
                            <i class="fa ti-panel tz-icon-color icon-extra-large text-sky-blue margin-twenty-bottom xs-margin-nine-bottom" aria-hidden="true"></i>
                            <h3 class="text-medium sm-text-medium alt-font display-block margin-three-bottom xs-margin-five-bottom tz-text">EASY TO USE</h3>
                            <div class="text-medium center-col xs-width-100 tz-text"><p class="no-margin-bottom">Lorem Ipsum is simply dummy text printing and typesetting and industry. Lorem Ipsum been.</p></div>
                        </div>    
                        <!-- end feature box -->
                        <!-- feature box -->
                        <div class="col-md-3 col-sm-6 col-xs-12 text-center sm-margin-nine-bottom xs-margin-seventeen-bottom">
                            <i class="fa ti-headphone-alt tz-icon-color icon-extra-large text-sky-blue margin-twenty-bottom xs-margin-nine-bottom" aria-hidden="true"></i>
                            <h3 class="text-medium sm-text-medium alt-font display-block margin-three-bottom xs-margin-five-bottom tz-text">DEDICATED SUPPORT</h3>
                            <div class="text-medium center-col xs-width-100 tz-text"><p class="no-margin-bottom">Lorem Ipsum is simply dummy text printing and typesetting and industry. Lorem Ipsum been.</p></div>
                        </div>    
                        <!-- end feature box -->
                        <!-- feature box -->
                        <div class="col-md-3 col-sm-6 col-xs-12 text-center sm-margin-nine-bottom">
                            <i class="fa ti-pencil-alt tz-icon-color icon-extra-large text-sky-blue margin-twenty-bottom xs-margin-nine-bottom" aria-hidden="true"></i>
                            <h3 class="text-medium sm-text-medium alt-font display-block margin-three-bottom xs-margin-five-bottom tz-text">PIXEL PERFECT DESIGN</h3>
                            <div class="text-medium center-col xs-width-100 tz-text"><p class="no-margin-bottom">Lorem Ipsum is simply dummy text printing and typesetting and industry. Lorem Ipsum been.</p></div>
                        </div>    
                        <!-- end feature box -->
                    </div>
                </div>                
            </section><?php include('footer.php'); ?></div><!-- /#page -->


        <!-- javascript libraries -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery.appear.js"></script>
        <script type="text/javascript" src="js/smooth-scroll.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <!-- wow animation -->
        <script type="text/javascript" src="js/wow.min.js"></script>
        <!-- owl carousel -->
        <script type="text/javascript" src="js/owl.carousel.min.js"></script>        
        <!-- images loaded -->
        <script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
        <!-- isotope -->
        <script type="text/javascript" src="js/jquery.isotope.min.js"></script> 
        <!-- magnific popup -->
        <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
        <!-- navigation -->
        <script type="text/javascript" src="js/jquery.nav.js"></script>
        <!-- equalize -->
        <script type="text/javascript" src="js/equalize.min.js"></script>
        <!-- fit videos -->
        <script type="text/javascript" src="js/jquery.fitvids.js"></script>
        <!-- number counter -->
        <script type="text/javascript" src="js/jquery.countTo.js"></script>
        <!-- time counter  -->
        <script type="text/javascript" src="js/counter.js"></script>
        <!-- twitter Fetcher  -->
        <script type="text/javascript" src="js/twitterFetcher_min.js"></script>
        <!-- main -->
        <script type="text/javascript" src="js/main.js"></script>
    

    </body>
</html>
        