<footer id="footer-section13" class="bg-dark-blue padding-60px-tb xs-padding-40px-tb builder-bg">
                <div class="container">
                    <div class="row">
                        <!-- logo -->
                        <div class="col-md-3 col-sm-12 col-xs-12 sm-text-center sm-margin-five-bottom">
                            <a href="#home" class="inner-link"><img src="images/logo-white.png" data-img-size="(W)163px X (H)40px" alt=""></a>
                        </div>
                        <!-- end logo -->
                        <!-- caption -->
                        <div class="col-md-6 col-sm-12 col-xs-12 text-center sm-margin-five-bottom">
                            <div class="tz-text text-white text-medium sm-margin-two-bottom"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit laudantium architecto maiores deserunt suscipit perferendis repellat.</p></div>
                        </div>
                        <!-- end caption -->
                        <!-- social elements -->
                        <div class="col-md-3 col-sm-12 col-xs-12 text-right sm-text-center social-icon">
                            <a href="#">
                                <i class="fa fa-facebook text-white tz-icon-color" aria-hidden="true"></i>
                            </a>
                            <a href="#">
                                <i class="fa fa-google-plus text-white tz-icon-color" aria-hidden="true"></i>
                            </a>
                            <a href="#">
                                <i class="fa fa-twitter text-white tz-icon-color" aria-hidden="true"></i>
                            </a>
                            <a href="#">
                                <i class="fa fa-pinterest text-white tz-icon-color" aria-hidden="true"></i>
                            </a>
                        </div>
                        <!-- end social elements -->
                        <div class="col-md-12 col-sm-12 col-xs-12 display-table margin-six-top">
                            <div class="display-table-cell-vertical-middle text-center border-top-light padding-six-top tz-border">
                                <span class="text-extra-small tz-text text-blue-gray">© 2018 Sitio web creado con 2WEB <a class="text-blue-gray" href="https://www.somos.mx/">SOMOS Multimedia®.</a></span>
                            </div>
                        </div>
                    </div>
                </div>
</footer>